PORTFOLIO MARLON
================

Struktur folder
  index.html              halaman utama
  assets/css/styles.css   gaya kustom (box model, flexbox, animasi, media query)
  assets/js/main.js       menu mobile, mode gelap/terang, animasi scroll, validasi form
  assets/img/             tempat gambar (profil.svg adalah gambar contoh)

Cara menjalankan
  Klik dua kali index.html, atau pakai ekstensi Live Server di VS Code.
  Perlu koneksi internet untuk memuat Tailwind CSS dan Google Fonts dari CDN.

Mengganti foto profil
  1. Simpan foto persegi (sekitar 800 x 800 px) di assets/img/, misalnya foto-profil.jpg
  2. Di index.html, ubah src pada gambar di dalam <div class="blob"> menjadi
     assets/img/foto-profil.jpg
  3. Di assets/css/styles.css, ubah aturan ".blob img" menjadi:
       width: 100%; height: 100%; object-fit: cover;

Data diri, proyek, dan statistik di halaman ini adalah contoh. Silakan ganti.
